def f(x):
    return x**2 - 612

def df(x):
    return 2 * x